from rest_framework import serializers
from .models import StudentEnroll

class StudentSerializer(serializers.Serializer):
    Student_id=serializers.CharField(max_length=100)
    Student_name=serializers.CharField(max_length=100)
    Student_dept=serializers.CharField(max_length=50)
    Student_year=serializers.IntegerField()
    Student_mail=serializers.EmailField()
    Student_addr=serializers.CharField(max_length=100)
    Student_contact=serializers.IntegerField()
    Student_profile=serializers.ImageField()
    class Meta:
        model=StudentEnroll
        fields="__all__",
        
    def create(self,validated_data):
     return StudentEnroll.objects.create(**validated_data)
    def update(self,instance,validated_data):
     instance.Student_id=validated_data.get('Student_id',instance.Student_id)
     instance.Student_name=validated_data.get('Student_name',instance.Student_name)
     instance.Student_dept=validated_data.get('Student_dept',instance.Student_dept)
     instance.Student_year=validated_data.get('Student_year',instance.Student_year)
     instance.Student_mail=validated_data.get('Student_mail',instance.Student_mail)
     instance.Student_addr=validated_data.get('Student_addr',instance.Student_addr)
     instance.Student_contact=validated_data.get('Student_contact',instance.Student_contact)
     instance.Student_profile=validated_data.get('Student_profile',instance.Student_profile)
     instance.save()
     return instance
# class searchform(serializers.Serializer):
#     Student_id=serializers.CharField(max_length=100)
    