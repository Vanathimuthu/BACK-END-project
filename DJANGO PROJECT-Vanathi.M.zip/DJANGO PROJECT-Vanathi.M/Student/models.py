from django.db import models
from PIL import Image
# Create your models here.
class StudentEnroll(models.Model):
    Student_id=models.CharField(max_length=100)
    Student_name=models.CharField( max_length=100)
    Student_dept=models.CharField( max_length=50)
    Student_year=models.IntegerField( )
    Student_mail=models.EmailField( )
    Student_addr=models.CharField( max_length=100)
    Student_contact=models.IntegerField( )
    Student_profile=models.ImageField(upload_to='profile_images/', blank=True)
    

    def __str__(self):
        return self.id+""+self.Student_id+""+self.Student_name+""+self.Student_dept+""+self.Student_year+""+self.Student_mail+""+self.Student_addr+""+self.Student_contact+""+self.Student_profile
   
    # def save(self, *args, **kwargs):
    #     super().save(*args, **kwargs)
    #     if self.Student_profile:
    #         img = Image.open(self.Student_profile.path)
    #         if img.height > 300 or img.width > 300:
    #             output_size = (300, 300)
    #             img.thumbnail(output_size)
    #             img.save(self.Student_profile.path)