from django.shortcuts import render,redirect
from rest_framework.views import Response
from .models import StudentEnroll
from .serializers import StudentSerializer
from django.shortcuts import get_object_or_404
from rest_framework.decorators import api_view,renderer_classes
from rest_framework.renderers import TemplateHTMLRenderer,StaticHTMLRenderer

# Create your views here.

@api_view(['GET','POST'])
@renderer_classes((TemplateHTMLRenderer,))
def show(request):
    return Response(template_name="Student\\home.html")

@api_view(['GET','POST'])
@renderer_classes((TemplateHTMLRenderer,))
def save_data(request):
    title="New Students Register Here...."
    data=request.data
   
    saveData=StudentSerializer(data=data)
    context={
        'title':title,
        'serializer':saveData,
       
    }
    if saveData.is_valid():
        saveData.save()
        # Student_profile=saveData.instance
        return Response(template_name="Student/ackreg.html")
       
    
    return Response(context,template_name="Student\\studentform.html")

@api_view(['GET','POST'])
@renderer_classes((TemplateHTMLRenderer,))
def get_data(request):
    getData=StudentEnroll.objects.all()
    title="All Registered Students Details:"
    context={"title":title,'serializer':getData}
    return Response(context,template_name="Student\\studentdata.html")

# @api_view(['GET','POST'])
# @renderer_classes((TemplateHTMLRenderer,))
# def search_data(request,Student_id):
#     getDataid=StudentEnroll.objects.get(Student_id=Student_id)
#     title="Search Here...!"
#     context={"title":title,'serializer':getDataid
#     }
#     if getDataid.is_valid():
#         getData=StudentEnroll.objects.filter(Student_id=Student_id)
#         Student_id=getDataid.cleaned_data["Student_id"]
#         getDataid.save()
#         context={"title":title,'serializer':getData}
#         return Response(context,template_name="Student/studentdata.html")
#     return Response(context,template_name="Student\\studentsearch.html")


@api_view(['GET'])
@renderer_classes((TemplateHTMLRenderer,))
def search_data( request,Student_id ):
    getDataid=StudentEnroll.objects.get(Student_id=Student_id)
    title="Search Here...."
    context={"title":title,'serializer':getDataid}
    return Response(context,template_name="Student\\studentupdate.html")

@api_view(['GET','POST'])
@renderer_classes((TemplateHTMLRenderer,))
def update_data(request,Student_id):
    update=StudentEnroll.objects.get(Student_id=Student_id)
    serializer= StudentSerializer(update,data=request.data,partial=True)
    if serializer.is_valid():
        serializer.save()
        return redirect('/showdata')   
    return Response({'serializer':serializer,'title':'Data updated successfully...!'},template_name="Student\\studentupdate.html")

@api_view(['GET','DELETE'])
@renderer_classes((TemplateHTMLRenderer,))
def delete_data(request,Student_id):
    deleted=StudentEnroll.objects.get(Student_id=Student_id)
    deleted.delete()
    return redirect('/showdata')  
   






