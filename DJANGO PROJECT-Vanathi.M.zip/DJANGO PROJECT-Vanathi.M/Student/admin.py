from django.contrib import admin
from Student.models import StudentEnroll
# from django.contrib.auth.models import User
# Register your models here.
admin.site.register(StudentEnroll)

# users = User.objects.all()
# for user in users:
#     print(user.username)
# exit()
# user = User.objects.get(username='admin')
# user.set_password('your_new_password')
# user.save()
# exit()